--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

-- Started on 2025-07-21 16:33:50 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS aima;
--
-- TOC entry 3592 (class 1262 OID 16384)
-- Name: aima; Type: DATABASE; Schema: -; Owner: aima_user
--

CREATE DATABASE aima WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE aima OWNER TO aima_user;

\connect aima

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 3593 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3594 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 279 (class 1255 OID 16601)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: aima_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO aima_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 16502)
-- Name: analysis_jobs; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.analysis_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_id character varying(255) NOT NULL,
    media_id uuid NOT NULL,
    job_type character varying(100) NOT NULL,
    job_status character varying(50) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 5,
    configuration jsonb,
    estimated_cost_cents integer,
    actual_cost_cents integer,
    gpu_instance_id character varying(255),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    retry_count integer DEFAULT 0,
    max_retries integer DEFAULT 3,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.analysis_jobs OWNER TO aima_user;

--
-- TOC entry 224 (class 1259 OID 16567)
-- Name: audit_log; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    action character varying(255) NOT NULL,
    resource_type character varying(100),
    resource_id character varying(255),
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_log OWNER TO aima_user;

--
-- TOC entry 228 (class 1259 OID 24593)
-- Name: configuration_history; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.configuration_history (
    id integer NOT NULL,
    config_key character varying(255) NOT NULL,
    old_value json,
    new_value json NOT NULL,
    change_type character varying(20) NOT NULL,
    changed_by character varying(255),
    change_reason text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    version_before integer,
    version_after integer NOT NULL
);


ALTER TABLE public.configuration_history OWNER TO aima_user;

--
-- TOC entry 227 (class 1259 OID 24592)
-- Name: configuration_history_id_seq; Type: SEQUENCE; Schema: public; Owner: aima_user
--

CREATE SEQUENCE public.configuration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configuration_history_id_seq OWNER TO aima_user;

--
-- TOC entry 3595 (class 0 OID 0)
-- Dependencies: 227
-- Name: configuration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aima_user
--

ALTER SEQUENCE public.configuration_history_id_seq OWNED BY public.configuration_history.id;


--
-- TOC entry 226 (class 1259 OID 24577)
-- Name: configuration_items; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.configuration_items (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value json NOT NULL,
    data_type character varying(50) NOT NULL,
    category character varying(100) NOT NULL,
    description text,
    is_sensitive boolean NOT NULL,
    is_readonly boolean NOT NULL,
    validation_schema json,
    default_value json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(255),
    updated_by character varying(255),
    version integer NOT NULL
);


ALTER TABLE public.configuration_items OWNER TO aima_user;

--
-- TOC entry 225 (class 1259 OID 24576)
-- Name: configuration_items_id_seq; Type: SEQUENCE; Schema: public; Owner: aima_user
--

CREATE SEQUENCE public.configuration_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configuration_items_id_seq OWNER TO aima_user;

--
-- TOC entry 3596 (class 0 OID 0)
-- Dependencies: 225
-- Name: configuration_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aima_user
--

ALTER SEQUENCE public.configuration_items_id_seq OWNED BY public.configuration_items.id;


--
-- TOC entry 232 (class 1259 OID 24621)
-- Name: configuration_locks; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.configuration_locks (
    id integer NOT NULL,
    config_key character varying(255) NOT NULL,
    locked_by character varying(255) NOT NULL,
    lock_reason character varying(255),
    locked_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.configuration_locks OWNER TO aima_user;

--
-- TOC entry 231 (class 1259 OID 24620)
-- Name: configuration_locks_id_seq; Type: SEQUENCE; Schema: public; Owner: aima_user
--

CREATE SEQUENCE public.configuration_locks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configuration_locks_id_seq OWNER TO aima_user;

--
-- TOC entry 3597 (class 0 OID 0)
-- Dependencies: 231
-- Name: configuration_locks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aima_user
--

ALTER SEQUENCE public.configuration_locks_id_seq OWNED BY public.configuration_locks.id;


--
-- TOC entry 230 (class 1259 OID 24607)
-- Name: configuration_templates; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.configuration_templates (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    template_data json NOT NULL,
    category character varying(100) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(255)
);


ALTER TABLE public.configuration_templates OWNER TO aima_user;

--
-- TOC entry 229 (class 1259 OID 24606)
-- Name: configuration_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: aima_user
--

CREATE SEQUENCE public.configuration_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configuration_templates_id_seq OWNER TO aima_user;

--
-- TOC entry 3598 (class 0 OID 0)
-- Dependencies: 229
-- Name: configuration_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aima_user
--

ALTER SEQUENCE public.configuration_templates_id_seq OWNED BY public.configuration_templates.id;


--
-- TOC entry 221 (class 1259 OID 16528)
-- Name: gpu_instances; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.gpu_instances (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    instance_id character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    instance_type character varying(100) NOT NULL,
    gpu_count integer DEFAULT 1 NOT NULL,
    memory_gb integer,
    vcpus integer,
    storage_gb integer,
    hourly_cost_cents integer,
    region character varying(100),
    status character varying(50) NOT NULL,
    external_ip character varying(45),
    internal_ip character varying(45),
    ssh_port integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp with time zone,
    terminated_at timestamp with time zone,
    last_heartbeat timestamp with time zone
);


ALTER TABLE public.gpu_instances OWNER TO aima_user;

--
-- TOC entry 222 (class 1259 OID 16540)
-- Name: job_gpu_assignments; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.job_gpu_assignments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_id uuid NOT NULL,
    gpu_instance_id uuid NOT NULL,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    status character varying(50) DEFAULT 'assigned'::character varying
);


ALTER TABLE public.job_gpu_assignments OWNER TO aima_user;

--
-- TOC entry 219 (class 1259 OID 16483)
-- Name: media_files; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.media_files (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    media_id character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_type character varying(50) NOT NULL,
    mime_type character varying(100) NOT NULL,
    file_size_bytes bigint NOT NULL,
    duration_seconds numeric(10,3),
    resolution character varying(20),
    fps numeric(5,2),
    file_hash character varying(64) NOT NULL,
    storage_provider character varying(50) NOT NULL,
    storage_bucket character varying(255),
    storage_path character varying(500) NOT NULL,
    upload_status character varying(50) DEFAULT 'pending'::character varying,
    processing_status character varying(50) DEFAULT 'pending'::character varying,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.media_files OWNER TO aima_user;

--
-- TOC entry 218 (class 1259 OID 16465)
-- Name: system_config; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.system_config (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    config_key character varying(255) NOT NULL,
    config_value jsonb NOT NULL,
    description text,
    is_sensitive boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid
);


ALTER TABLE public.system_config OWNER TO aima_user;

--
-- TOC entry 223 (class 1259 OID 16558)
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    metric_name character varying(255) NOT NULL,
    metric_value numeric(15,6) NOT NULL,
    metric_unit character varying(50),
    tags jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_metrics OWNER TO aima_user;

--
-- TOC entry 217 (class 1259 OID 16449)
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    session_token character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address inet,
    user_agent text
);


ALTER TABLE public.user_sessions OWNER TO aima_user;

--
-- TOC entry 216 (class 1259 OID 16433)
-- Name: users; Type: TABLE; Schema: public; Owner: aima_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp with time zone
);


ALTER TABLE public.users OWNER TO aima_user;

--
-- TOC entry 3335 (class 2604 OID 24596)
-- Name: configuration_history id; Type: DEFAULT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_history ALTER COLUMN id SET DEFAULT nextval('public.configuration_history_id_seq'::regclass);


--
-- TOC entry 3332 (class 2604 OID 24580)
-- Name: configuration_items id; Type: DEFAULT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_items ALTER COLUMN id SET DEFAULT nextval('public.configuration_items_id_seq'::regclass);


--
-- TOC entry 3340 (class 2604 OID 24624)
-- Name: configuration_locks id; Type: DEFAULT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_locks ALTER COLUMN id SET DEFAULT nextval('public.configuration_locks_id_seq'::regclass);


--
-- TOC entry 3337 (class 2604 OID 24610)
-- Name: configuration_templates id; Type: DEFAULT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_templates ALTER COLUMN id SET DEFAULT nextval('public.configuration_templates_id_seq'::regclass);


--
-- TOC entry 3574 (class 0 OID 16502)
-- Dependencies: 220
-- Data for Name: analysis_jobs; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.analysis_jobs (id, job_id, media_id, job_type, job_status, priority, configuration, estimated_cost_cents, actual_cost_cents, gpu_instance_id, started_at, completed_at, error_message, retry_count, max_retries, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3578 (class 0 OID 16567)
-- Dependencies: 224
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.audit_log (id, user_id, action, resource_type, resource_id, old_values, new_values, ip_address, user_agent, "timestamp") FROM stdin;
\.


--
-- TOC entry 3582 (class 0 OID 24593)
-- Dependencies: 228
-- Data for Name: configuration_history; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.configuration_history (id, config_key, old_value, new_value, change_type, changed_by, change_reason, changed_at, version_before, version_after) FROM stdin;
\.


--
-- TOC entry 3580 (class 0 OID 24577)
-- Dependencies: 226
-- Data for Name: configuration_items; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.configuration_items (id, key, value, data_type, category, description, is_sensitive, is_readonly, validation_schema, default_value, created_at, updated_at, created_by, updated_by, version) FROM stdin;
\.


--
-- TOC entry 3586 (class 0 OID 24621)
-- Dependencies: 232
-- Data for Name: configuration_locks; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.configuration_locks (id, config_key, locked_by, lock_reason, locked_at, expires_at) FROM stdin;
\.


--
-- TOC entry 3584 (class 0 OID 24607)
-- Dependencies: 230
-- Data for Name: configuration_templates; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.configuration_templates (id, name, description, template_data, category, is_active, created_at, updated_at, created_by) FROM stdin;
\.


--
-- TOC entry 3575 (class 0 OID 16528)
-- Dependencies: 221
-- Data for Name: gpu_instances; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.gpu_instances (id, instance_id, provider, instance_type, gpu_count, memory_gb, vcpus, storage_gb, hourly_cost_cents, region, status, external_ip, internal_ip, ssh_port, created_at, started_at, terminated_at, last_heartbeat) FROM stdin;
\.


--
-- TOC entry 3576 (class 0 OID 16540)
-- Dependencies: 222
-- Data for Name: job_gpu_assignments; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.job_gpu_assignments (id, job_id, gpu_instance_id, assigned_at, started_at, completed_at, status) FROM stdin;
\.


--
-- TOC entry 3573 (class 0 OID 16483)
-- Dependencies: 219
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.media_files (id, media_id, filename, original_filename, file_type, mime_type, file_size_bytes, duration_seconds, resolution, fps, file_hash, storage_provider, storage_bucket, storage_path, upload_status, processing_status, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3572 (class 0 OID 16465)
-- Dependencies: 218
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.system_config (id, config_key, config_value, description, is_sensitive, created_at, updated_at, updated_by) FROM stdin;
0b72e662-08c3-42fb-9833-12b09d24fb4e	system.name	"AIMA - AI Media Analysis"	System display name	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
8306fb4c-d7e6-43a4-bbbb-218d39ea40b5	system.version	"1.0.0"	Current system version	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
165b34bf-5e5d-4362-8cb7-11fc110a4ce1	system.maintenance_mode	false	Enable/disable maintenance mode	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
1e8a8efd-1634-40e2-bd3b-1ea29b857ec6	system.max_upload_size_mb	1000	Maximum file upload size in MB	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
ee63af3b-975d-4141-af33-ad7b1b038d8f	system.supported_video_formats	["mp4", "avi", "mov", "mkv", "webm"]	Supported video file formats	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
d847b438-2a42-4fc0-9d88-46ca9e9c502a	system.supported_audio_formats	["mp3", "wav", "flac", "aac", "ogg"]	Supported audio file formats	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
1dd83135-e526-46f7-b375-d00b95430a09	system.supported_image_formats	["jpg", "jpeg", "png", "bmp", "tiff", "webp"]	Supported image file formats	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
53594040-c3fa-4372-bf69-bcd8ffc9a10e	system.default_analysis_timeout_minutes	60	Default timeout for analysis jobs in minutes	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
fd142695-2da9-4ec0-985f-4521e36f69cf	system.max_concurrent_jobs	10	Maximum number of concurrent analysis jobs	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
620b3763-c10e-41ea-9910-692c41bfc321	system.job_retry_attempts	3	Number of retry attempts for failed jobs	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
94f97f49-d56a-481d-b6f2-54c3d7ee50df	storage.default_provider	"minio"	Default storage provider	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
3c977b62-1a34-4e2f-b1bf-ab5d9c42db06	storage.minio.endpoint	"minio:9000"	MinIO endpoint	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
3ec939a0-52aa-4904-844e-ace2a2753600	storage.minio.access_key	"aima_user"	MinIO access key	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
9288066c-23d8-49c2-a28c-c62b797d334e	storage.minio.secret_key	"aima_password"	MinIO secret key	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
e651ea76-1a49-49ad-a13d-d1aeb3c8c857	storage.minio.bucket_media	"aima-media"	MinIO bucket for media files	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
310e182d-f725-40d4-ad37-92e1edb06927	storage.minio.bucket_results	"aima-results"	MinIO bucket for analysis results	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
2a2fea5d-d040-4e4e-a3a0-570d95b9085b	storage.retention_days	365	Default file retention period in days	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
4d7984c6-4231-47c2-82ba-4288a13fdac8	database.mongodb.connection_string	"mongodb://aima_user:aima_password@mongodb:27017/aima"	MongoDB connection string	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
2179efef-d136-4baa-8ff4-6c58869c36f4	database.redis.connection_string	"redis://:aima_password@redis:6379/0"	Redis connection string	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
307cff56-bc93-47c5-8bf2-f7a1ae1ac3e3	database.milvus.endpoint	"milvus:19530"	Milvus endpoint	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
58df1023-f410-4366-b531-8be5766a64f0	messaging.rabbitmq.connection_string	"amqp://aima_user:aima_password@rabbitmq:5672/"	RabbitMQ connection string	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
51aa11af-97a6-43c3-9aa5-790af1236da4	messaging.default_queue_ttl_hours	24	Default message TTL in hours	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
8826791a-5739-49e1-a794-a45fd46a8b69	gpu.providers.enabled	["local", "runpod", "vast_ai"]	Enabled GPU providers	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
507757ac-3862-4fe1-b7bd-a79a2decec1b	gpu.local.enabled	true	Enable local GPU usage	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
7ca1bcc0-b5fc-41a0-b32f-c187bda3529b	gpu.runpod.api_key	""	RunPod API key	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
be5dc082-ebad-4caa-b774-67ac07d01b35	gpu.vast_ai.api_key	""	Vast.ai API key	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
323a608e-d77e-497c-a9a7-4d1d9b832ada	gpu.auto_scaling.enabled	true	Enable automatic GPU scaling	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
94419ee4-2f25-4334-81f7-19b9c131c38a	gpu.auto_scaling.min_instances	0	Minimum GPU instances	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
f27617bd-0eb4-4a10-8d3f-f01a1658e027	gpu.auto_scaling.max_instances	5	Maximum GPU instances	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
ded6fc77-2a12-458f-8ce2-1224466886d3	gpu.idle_timeout_minutes	10	GPU instance idle timeout in minutes	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
079165f3-2037-4ca6-85c8-88100df08e86	analysis.video.default_fps	30	Default FPS for video analysis	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
497f5848-e264-4d0d-9156-2a6cfb5c7e2b	analysis.video.max_resolution	"1920x1080"	Maximum video resolution for analysis	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
d0cb3e25-f79f-4e1a-b1b7-d6aaf61c1315	analysis.audio.sample_rate	44100	Audio sample rate for analysis	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
1fe022ec-94a0-4688-b724-2b6b0c9ee5ea	analysis.image.max_size_mb	50	Maximum image size for analysis in MB	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
2b5691bf-8b0d-4286-b713-f05642c7c6ad	analysis.models.face_detection	"retinaface"	Default face detection model	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
9f49bbff-fddc-44ca-aac8-0e400b651f16	analysis.models.object_detection	"yolov8"	Default object detection model	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
2e7f5769-1d64-40e7-af0c-1dd9de0eb5c6	analysis.models.speech_recognition	"whisper"	Default speech recognition model	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
822e8bd0-a27c-420a-94dd-926f69a5899e	analysis.models.llm_fusion	"llama3.1"	Default LLM for data fusion	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
c6e79fd6-fd8c-4179-9da3-e0ced1d1a1b5	security.jwt.secret_key	"your-super-secret-jwt-key-change-this-in-production"	JWT secret key	t	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
d37c3aea-3a4b-43c5-8410-3aae219d7faf	security.jwt.expiration_hours	24	JWT token expiration in hours	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
3c131c67-e7c1-4dd1-8963-e23e38270fa8	security.password.min_length	8	Minimum password length	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
9f97e3d7-ce89-4143-8a6c-0a6926826022	security.password.require_special_chars	true	Require special characters in passwords	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
e982188f-a130-4a14-afdd-6fcb6886d7ce	security.session.timeout_hours	8	Session timeout in hours	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
0101a4f8-a86f-4fcd-8a9a-6f9f7eafb478	security.rate_limiting.enabled	true	Enable rate limiting	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
c0ce54f9-e39d-46ff-b413-7968638ecada	security.rate_limiting.requests_per_minute	100	Maximum requests per minute per user	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
b179ce2c-c763-439e-b534-318805d718fc	monitoring.metrics.enabled	true	Enable metrics collection	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
92213b40-d74b-484b-9fe1-51fb2c5db2c0	monitoring.metrics.retention_days	30	Metrics retention period in days	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
e5236e34-3ad4-4a85-b03e-f65f1548c4ce	monitoring.alerts.enabled	true	Enable alerting	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
d8925da0-94e9-4313-aa0d-390864992923	monitoring.alerts.email_notifications	true	Enable email notifications for alerts	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
d5c1d1f3-cb13-4ac3-9d80-7ed1b49acf22	cost.tracking.enabled	true	Enable cost tracking	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
126a8bd0-1939-4743-a47c-4c84d73bad58	cost.gpu.runpod_markup_percent	10	Markup percentage for RunPod costs	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
fcfd16f7-1717-4ca3-8d1b-32d866cf483b	cost.gpu.vast_ai_markup_percent	10	Markup percentage for Vast.ai costs	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
a45f9ccd-6aa4-4e2f-a967-415697063955	cost.storage.per_gb_per_month_cents	5	Storage cost per GB per month in cents	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
f1da114f-edf2-4d23-9bd0-ad7ce77e9859	cost.analysis.base_cost_cents	10	Base cost per analysis in cents	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
f1336682-0637-4e7d-8281-9e41d4fff4a0	features.advanced_analytics	true	Enable advanced analytics features	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
7bed7f92-70f8-41f2-95cf-92892a13598f	features.real_time_processing	false	Enable real-time processing (experimental)	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
ce18f880-0068-406b-9bfc-ed97f45becf7	features.multi_language_support	true	Enable multi-language support	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
fafb0ed9-02eb-425c-9373-e158c85dd231	features.api_v2	false	Enable API v2 (experimental)	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
083078b6-8785-40c3-a6be-f51a9592b358	features.mobile_app	false	Enable mobile app support	f	2025-07-21 15:36:50.810432+00	2025-07-21 15:36:50.810432+00	\N
\.


--
-- TOC entry 3577 (class 0 OID 16558)
-- Dependencies: 223
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.system_metrics (id, metric_name, metric_value, metric_unit, tags, "timestamp") FROM stdin;
\.


--
-- TOC entry 3571 (class 0 OID 16449)
-- Dependencies: 217
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.user_sessions (id, user_id, session_token, expires_at, created_at, ip_address, user_agent) FROM stdin;
\.


--
-- TOC entry 3570 (class 0 OID 16433)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aima_user
--

COPY public.users (id, username, email, password_hash, first_name, last_name, role, is_active, created_at, updated_at, last_login) FROM stdin;
f63e3417-5649-47c0-8831-ff7beacdd283	admin	admin@aima.local	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj3bp.Gm.F5e	System	Administrator	admin	t	2025-07-21 15:36:50.804909+00	2025-07-21 15:36:50.804909+00	\N
\.


--
-- TOC entry 3599 (class 0 OID 0)
-- Dependencies: 227
-- Name: configuration_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aima_user
--

SELECT pg_catalog.setval('public.configuration_history_id_seq', 1, false);


--
-- TOC entry 3600 (class 0 OID 0)
-- Dependencies: 225
-- Name: configuration_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aima_user
--

SELECT pg_catalog.setval('public.configuration_items_id_seq', 1, false);


--
-- TOC entry 3601 (class 0 OID 0)
-- Dependencies: 231
-- Name: configuration_locks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aima_user
--

SELECT pg_catalog.setval('public.configuration_locks_id_seq', 1, false);


--
-- TOC entry 3602 (class 0 OID 0)
-- Dependencies: 229
-- Name: configuration_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aima_user
--

SELECT pg_catalog.setval('public.configuration_templates_id_seq', 1, false);


--
-- TOC entry 3369 (class 2606 OID 16517)
-- Name: analysis_jobs analysis_jobs_job_id_key; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.analysis_jobs
    ADD CONSTRAINT analysis_jobs_job_id_key UNIQUE (job_id);


--
-- TOC entry 3371 (class 2606 OID 16515)
-- Name: analysis_jobs analysis_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.analysis_jobs
    ADD CONSTRAINT analysis_jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 3391 (class 2606 OID 16575)
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3402 (class 2606 OID 24601)
-- Name: configuration_history configuration_history_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_history
    ADD CONSTRAINT configuration_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3395 (class 2606 OID 24586)
-- Name: configuration_items configuration_items_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_items
    ADD CONSTRAINT configuration_items_pkey PRIMARY KEY (id);


--
-- TOC entry 3413 (class 2606 OID 24629)
-- Name: configuration_locks configuration_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_locks
    ADD CONSTRAINT configuration_locks_pkey PRIMARY KEY (id);


--
-- TOC entry 3408 (class 2606 OID 24616)
-- Name: configuration_templates configuration_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.configuration_templates
    ADD CONSTRAINT configuration_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3377 (class 2606 OID 16539)
-- Name: gpu_instances gpu_instances_instance_id_key; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.gpu_instances
    ADD CONSTRAINT gpu_instances_instance_id_key UNIQUE (instance_id);


--
-- TOC entry 3379 (class 2606 OID 16537)
-- Name: gpu_instances gpu_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.gpu_instances
    ADD CONSTRAINT gpu_instances_pkey PRIMARY KEY (id);


--
-- TOC entry 3386 (class 2606 OID 16547)
-- Name: job_gpu_assignments job_gpu_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.job_gpu_assignments
    ADD CONSTRAINT job_gpu_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 3365 (class 2606 OID 16496)
-- Name: media_files media_files_media_id_key; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_media_id_key UNIQUE (media_id);


--
-- TOC entry 3367 (class 2606 OID 16494)
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- TOC entry 3358 (class 2606 OID 16477)
-- Name: system_config system_config_config_key_key; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_config_key_key UNIQUE (config_key);


--
-- TOC entry 3360 (class 2606 OID 16475)
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (id);


--
-- TOC entry 3389 (class 2606 OID 16566)
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3353 (class 2606 OID 16457)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3355 (class 2606 OID 16459)
-- Name: user_sessions user_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_key UNIQUE (session_token);


--
-- TOC entry 3345 (class 2606 OID 16448)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3347 (class 2606 OID 16444)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3349 (class 2606 OID 16446)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3372 (class 1259 OID 16589)
-- Name: idx_analysis_jobs_job_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_analysis_jobs_job_id ON public.analysis_jobs USING btree (job_id);


--
-- TOC entry 3373 (class 1259 OID 16590)
-- Name: idx_analysis_jobs_media_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_analysis_jobs_media_id ON public.analysis_jobs USING btree (media_id);


--
-- TOC entry 3374 (class 1259 OID 16592)
-- Name: idx_analysis_jobs_priority; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_analysis_jobs_priority ON public.analysis_jobs USING btree (priority);


--
-- TOC entry 3375 (class 1259 OID 16591)
-- Name: idx_analysis_jobs_status; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_analysis_jobs_status ON public.analysis_jobs USING btree (job_status);


--
-- TOC entry 3392 (class 1259 OID 16600)
-- Name: idx_audit_log_timestamp; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_audit_log_timestamp ON public.audit_log USING btree ("timestamp");


--
-- TOC entry 3393 (class 1259 OID 16599)
-- Name: idx_audit_log_user_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- TOC entry 3396 (class 1259 OID 24588)
-- Name: idx_config_category_key; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_config_category_key ON public.configuration_items USING btree (category, key);


--
-- TOC entry 3403 (class 1259 OID 24602)
-- Name: idx_config_history_changed_by; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_config_history_changed_by ON public.configuration_history USING btree (changed_by);


--
-- TOC entry 3404 (class 1259 OID 24605)
-- Name: idx_config_history_key_time; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_config_history_key_time ON public.configuration_history USING btree (config_key, changed_at);


--
-- TOC entry 3397 (class 1259 OID 24590)
-- Name: idx_config_updated_at; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_config_updated_at ON public.configuration_items USING btree (updated_at);


--
-- TOC entry 3380 (class 1259 OID 16593)
-- Name: idx_gpu_instances_instance_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_gpu_instances_instance_id ON public.gpu_instances USING btree (instance_id);


--
-- TOC entry 3381 (class 1259 OID 16594)
-- Name: idx_gpu_instances_provider; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_gpu_instances_provider ON public.gpu_instances USING btree (provider);


--
-- TOC entry 3382 (class 1259 OID 16595)
-- Name: idx_gpu_instances_status; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_gpu_instances_status ON public.gpu_instances USING btree (status);


--
-- TOC entry 3383 (class 1259 OID 16597)
-- Name: idx_job_gpu_assignments_gpu_instance_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_job_gpu_assignments_gpu_instance_id ON public.job_gpu_assignments USING btree (gpu_instance_id);


--
-- TOC entry 3384 (class 1259 OID 16596)
-- Name: idx_job_gpu_assignments_job_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_job_gpu_assignments_job_id ON public.job_gpu_assignments USING btree (job_id);


--
-- TOC entry 3361 (class 1259 OID 16587)
-- Name: idx_media_files_hash; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_media_files_hash ON public.media_files USING btree (file_hash);


--
-- TOC entry 3362 (class 1259 OID 16586)
-- Name: idx_media_files_media_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_media_files_media_id ON public.media_files USING btree (media_id);


--
-- TOC entry 3363 (class 1259 OID 16588)
-- Name: idx_media_files_uploaded_by; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_media_files_uploaded_by ON public.media_files USING btree (uploaded_by);


--
-- TOC entry 3356 (class 1259 OID 16585)
-- Name: idx_system_config_key; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_system_config_key ON public.system_config USING btree (config_key);


--
-- TOC entry 3387 (class 1259 OID 16598)
-- Name: idx_system_metrics_name_timestamp; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_system_metrics_name_timestamp ON public.system_metrics USING btree (metric_name, "timestamp");


--
-- TOC entry 3350 (class 1259 OID 16583)
-- Name: idx_user_sessions_token; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_user_sessions_token ON public.user_sessions USING btree (session_token);


--
-- TOC entry 3351 (class 1259 OID 16584)
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- TOC entry 3342 (class 1259 OID 16582)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3343 (class 1259 OID 16581)
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- TOC entry 3405 (class 1259 OID 24603)
-- Name: ix_configuration_history_config_key; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX ix_configuration_history_config_key ON public.configuration_history USING btree (config_key);


--
-- TOC entry 3406 (class 1259 OID 24604)
-- Name: ix_configuration_history_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX ix_configuration_history_id ON public.configuration_history USING btree (id);


--
-- TOC entry 3398 (class 1259 OID 24589)
-- Name: ix_configuration_items_category; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX ix_configuration_items_category ON public.configuration_items USING btree (category);


--
-- TOC entry 3399 (class 1259 OID 24587)
-- Name: ix_configuration_items_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX ix_configuration_items_id ON public.configuration_items USING btree (id);


--
-- TOC entry 3400 (class 1259 OID 24591)
-- Name: ix_configuration_items_key; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE UNIQUE INDEX ix_configuration_items_key ON public.configuration_items USING btree (key);


--
-- TOC entry 3414 (class 1259 OID 24631)
-- Name: ix_configuration_locks_config_key; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE UNIQUE INDEX ix_configuration_locks_config_key ON public.configuration_locks USING btree (config_key);


--
-- TOC entry 3415 (class 1259 OID 24630)
-- Name: ix_configuration_locks_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX ix_configuration_locks_id ON public.configuration_locks USING btree (id);


--
-- TOC entry 3409 (class 1259 OID 24617)
-- Name: ix_configuration_templates_category; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX ix_configuration_templates_category ON public.configuration_templates USING btree (category);


--
-- TOC entry 3410 (class 1259 OID 24619)
-- Name: ix_configuration_templates_id; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE INDEX ix_configuration_templates_id ON public.configuration_templates USING btree (id);


--
-- TOC entry 3411 (class 1259 OID 24618)
-- Name: ix_configuration_templates_name; Type: INDEX; Schema: public; Owner: aima_user
--

CREATE UNIQUE INDEX ix_configuration_templates_name ON public.configuration_templates USING btree (name);


--
-- TOC entry 3427 (class 2620 OID 16605)
-- Name: analysis_jobs update_analysis_jobs_updated_at; Type: TRIGGER; Schema: public; Owner: aima_user
--

CREATE TRIGGER update_analysis_jobs_updated_at BEFORE UPDATE ON public.analysis_jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3426 (class 2620 OID 16604)
-- Name: media_files update_media_files_updated_at; Type: TRIGGER; Schema: public; Owner: aima_user
--

CREATE TRIGGER update_media_files_updated_at BEFORE UPDATE ON public.media_files FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3425 (class 2620 OID 16603)
-- Name: system_config update_system_config_updated_at; Type: TRIGGER; Schema: public; Owner: aima_user
--

CREATE TRIGGER update_system_config_updated_at BEFORE UPDATE ON public.system_config FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3424 (class 2620 OID 16602)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: aima_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3419 (class 2606 OID 16523)
-- Name: analysis_jobs analysis_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.analysis_jobs
    ADD CONSTRAINT analysis_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3420 (class 2606 OID 16518)
-- Name: analysis_jobs analysis_jobs_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.analysis_jobs
    ADD CONSTRAINT analysis_jobs_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media_files(id) ON DELETE CASCADE;


--
-- TOC entry 3423 (class 2606 OID 16576)
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3421 (class 2606 OID 16553)
-- Name: job_gpu_assignments job_gpu_assignments_gpu_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.job_gpu_assignments
    ADD CONSTRAINT job_gpu_assignments_gpu_instance_id_fkey FOREIGN KEY (gpu_instance_id) REFERENCES public.gpu_instances(id) ON DELETE CASCADE;


--
-- TOC entry 3422 (class 2606 OID 16548)
-- Name: job_gpu_assignments job_gpu_assignments_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.job_gpu_assignments
    ADD CONSTRAINT job_gpu_assignments_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.analysis_jobs(id) ON DELETE CASCADE;


--
-- TOC entry 3418 (class 2606 OID 16497)
-- Name: media_files media_files_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- TOC entry 3417 (class 2606 OID 16478)
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- TOC entry 3416 (class 2606 OID 16460)
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aima_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-07-21 16:33:50 UTC

--
-- PostgreSQL database dump complete
--

